// ZapAfiliados - Chrome Extension Popup Script

const DEFAULT_SERVER_URL = 'http://localhost:3000';

document.addEventListener('DOMContentLoaded', async () => {
  const popupImg = document.getElementById('popup-img');
  const popupTitle = document.getElementById('popup-title');
  const popupPromo = document.getElementById('popup-promo');
  const popupOrig = document.getElementById('popup-orig');
  const popupDisc = document.getElementById('popup-disc');
  const previewBox = document.getElementById('popup-achadinho-preview');
  const copyBtn = document.getElementById('copy-achadinho-btn');
  const sendZapBtn = document.getElementById('send-zap-btn');
  const downloadImgBtn = document.getElementById('download-img-btn');
  const autoCopyToggle = document.getElementById('auto-copy-toggle');
  const statusMsg = document.getElementById('status-msg');
  const connBadge = document.getElementById('conn-badge');

  // Settings elements
  const toggleSettingsBtn = document.getElementById('toggle-settings-btn');
  const settingsPanel = document.getElementById('settings-panel');
  const meliInput = document.getElementById('meli-tag-input');
  const shopeeInput = document.getElementById('shopee-tag-input');
  const amazonInput = document.getElementById('amazon-tag-input');
  const serverInput = document.getElementById('server-url-input');
  const saveSettingsBtn = document.getElementById('save-settings-btn');
  const openDashboardLink = document.getElementById('open-dashboard-link');

  let currentProduct = null;
  let currentAchadinhoText = '';
  let serverUrl = DEFAULT_SERVER_URL;

  // Toggle settings
  toggleSettingsBtn.addEventListener('click', () => {
    settingsPanel.style.display = settingsPanel.style.display === 'none' ? 'block' : 'none';
  });

  // Load saved tags & settings
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.get(['zapServerUrl', 'meliTag', 'shopeeTag', 'amazonTag', 'autoCopyOnOpen'], (res) => {
      serverUrl = res.zapServerUrl || DEFAULT_SERVER_URL;
      serverInput.value = serverUrl;
      meliInput.value = res.meliTag || 'afiliado_zap_vip';
      shopeeInput.value = res.shopeeTag || 'shopee_vip_123';
      amazonInput.value = res.amazonTag || 'achadoszap-20';
      if (autoCopyToggle) {
        autoCopyToggle.checked = res.autoCopyOnOpen !== false;
      }

      openDashboardLink.href = serverUrl;
      testConnection(serverUrl);
    });

    if (autoCopyToggle) {
      autoCopyToggle.addEventListener('change', () => {
        chrome.storage.sync.set({ autoCopyOnOpen: autoCopyToggle.checked });
      });
    }
  }

  openDashboardLink.addEventListener('click', (e) => {
    e.preventDefault();
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url: serverUrl });
    } else {
      window.open(serverUrl, '_blank');
    }
  });

  // Save tags
  saveSettingsBtn.addEventListener('click', () => {
    const newServer = serverInput.value.trim().replace(/\/+$/, '') || DEFAULT_SERVER_URL;
    chrome.storage.sync.set(
      {
        zapServerUrl: newServer,
        meliTag: meliInput.value.trim() || 'afiliado_zap_vip',
        shopeeTag: shopeeInput.value.trim() || 'shopee_vip_123',
        amazonTag: amazonInput.value.trim() || 'achadoszap-20',
        autoCopyOnOpen: autoCopyToggle ? autoCopyToggle.checked : true,
      },
      () => {
        serverUrl = newServer;
        statusMsg.style.color = '#10b981';
        statusMsg.innerText = 'Configurações salvas!';
        settingsPanel.style.display = 'none';
        testConnection(newServer);
        setTimeout(() => (statusMsg.innerText = ''), 3000);
      }
    );
  });

  function testConnection(url) {
    fetch(`${url}/api/extension/status`)
      .then((r) => r.json())
      .then((d) => {
        if (d.online) {
          connBadge.innerText = 'Online';
          connBadge.style.color = '#10b981';
        }
      })
      .catch(() => {
        connBadge.innerText = 'Offline';
        connBadge.style.color = '#f59e0b';
      });
  }

  // Extract from active tab
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.id) {
      previewBox.innerText = 'Nenhuma aba ativa detectada.';
      return;
    }

    // Ask content script for extracted product
    chrome.tabs.sendMessage(tab.id, { action: 'extract_product' }, (response) => {
      if (chrome.runtime.lastError || !response || !response.product) {
        popupTitle.innerText = 'Abra uma página de produto no Mercado Livre, Shopee ou Amazon';
        previewBox.innerText =
          'Ao acessar qualquer produto, a extensão extrai automaticamente o link de afiliado, a 1ª foto, o nome e o preço, formatando no estilo Achadinhos WhatsApp com anti-duplicação.';
        return;
      }

      currentProduct = response.product;
      currentAchadinhoText = response.achadinhoText;

      // Populate UI
      popupTitle.innerText = currentProduct.title;
      popupPromo.innerText = `R$ ${currentProduct.promotionalPrice.toFixed(2).replace('.', ',')}`;
      if (currentProduct.originalPrice > currentProduct.promotionalPrice) {
        popupOrig.innerText = `R$ ${currentProduct.originalPrice.toFixed(2).replace('.', ',')}`;
      }
      if (currentProduct.discountPercentage > 0 && popupDisc) {
        popupDisc.innerText = `${currentProduct.discountPercentage}% OFF`;
        popupDisc.style.display = 'inline-block';
      }

      if (currentProduct.imageUrl) {
        popupImg.src = currentProduct.imageUrl;
        popupImg.style.display = 'block';
      }

      previewBox.innerText = currentAchadinhoText;

      // Check duplicate with backend
      fetch(
        `${serverUrl}/api/extension/check?url=${encodeURIComponent(currentProduct.originalUrl)}&externalId=${encodeURIComponent(currentProduct.externalId || '')}&title=${encodeURIComponent(currentProduct.title || '')}`
      )
        .then((r) => r.json())
        .then((res) => {
          if (res.exists) {
            statusMsg.style.color = '#f59e0b';
            statusMsg.innerText = '⚠️ Produto já no robô (anti-repetição ativo)';
          } else {
            statusMsg.style.color = '#10b981';
            statusMsg.innerText = '✨ Produto novo e pronto para postar!';
          }
        })
        .catch(() => {});
    });
  }

  // Copy Achadinho Text to Clipboard
  copyBtn.addEventListener('click', () => {
    if (!currentAchadinhoText) {
      statusMsg.style.color = '#f59e0b';
      statusMsg.innerText = 'Nenhum produto detectado nesta aba.';
      return;
    }

    navigator.clipboard.writeText(currentAchadinhoText).then(() => {
      copyBtn.style.background = '#059669';
      copyBtn.innerText = '✅ Copiado com Sucesso! Cole no WhatsApp';
      statusMsg.style.color = '#10b981';
      statusMsg.innerText = 'Texto formatado com negrito, tachado e emojis!';

      setTimeout(() => {
        copyBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
        copyBtn.innerText = '📋 Copiar Texto Achadinho (WhatsApp)';
      }, 3000);
    });
  });

  // Download Product Image
  downloadImgBtn.addEventListener('click', () => {
    if (!currentProduct || !currentProduct.imageUrl) {
      statusMsg.style.color = '#f59e0b';
      statusMsg.innerText = 'Nenhuma imagem encontrada.';
      return;
    }

    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url: currentProduct.imageUrl });
    } else {
      window.open(currentProduct.imageUrl, '_blank');
    }
  });

  // Send to ZapAfiliados Bot for Daily Dispatch
  sendZapBtn.addEventListener('click', () => {
    if (!currentProduct) {
      statusMsg.style.color = '#f59e0b';
      statusMsg.innerText = 'Nenhum produto detectado.';
      return;
    }

    sendZapBtn.disabled = true;
    sendZapBtn.innerText = 'Enviando...';

    fetch(`${serverUrl}/api/extension/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...currentProduct,
        addToDailySchedule: true,
      }),
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.success) {
          sendZapBtn.style.background = '#10b981';
          sendZapBtn.style.color = '#000';
          sendZapBtn.innerText = '✅ Agendado Hoje!';
          statusMsg.style.color = '#10b981';
          statusMsg.innerText = 'Adicionado aos disparos do dia sem repetir!';
        } else if (res.duplicate) {
          sendZapBtn.style.background = '#f59e0b';
          sendZapBtn.style.color = '#000';
          sendZapBtn.innerText = '⚠️ Já Cadastrado';
          statusMsg.style.color = '#f59e0b';
          statusMsg.innerText = 'Anti-duplicação evitou envio repetido.';
        } else {
          sendZapBtn.disabled = false;
          sendZapBtn.innerText = 'Tentar Novamente';
          statusMsg.style.color = '#ef4444';
          statusMsg.innerText = res.error || 'Erro ao enviar.';
        }
      })
      .catch(() => {
        sendZapBtn.disabled = false;
        sendZapBtn.innerText = 'Tentar Novamente';
        statusMsg.style.color = '#ef4444';
        statusMsg.innerText = 'Erro de conexão com o servidor ZapAfiliados.';
      });
  });
});
