// ZapAfiliados - Chrome Extension Content Script
// Captura link de afiliado, 1ª foto em alta resolução, nome e preço no ESTILO ACHADINHOS DO WHATSAPP com anti-duplicação.

(function () {
  if (window.__zapAfiliadosInjected) return;
  window.__zapAfiliadosInjected = true;

  const DEFAULT_SERVER_URL = window.location.origin.includes('localhost')
    ? 'http://localhost:3000'
    : window.location.origin;

  function getSettings(callback) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(['zapServerUrl', 'meliTag', 'shopeeTag', 'amazonTag', 'autoCopyOnOpen'], function (res) {
        callback({
          serverUrl: res.zapServerUrl || DEFAULT_SERVER_URL,
          meliTag: res.meliTag || 'afiliado_zap_vip',
          shopeeTag: res.shopeeTag || 'shopee_vip_123',
          amazonTag: res.amazonTag || 'achadoszap-20',
          autoCopyOnOpen: res.autoCopyOnOpen !== false, // default true: copia assim que clica/abre
        });
      });
    } else {
      callback({
        serverUrl: DEFAULT_SERVER_URL,
        meliTag: 'afiliado_zap_vip',
        shopeeTag: 'shopee_vip_123',
        amazonTag: 'achadoszap-20',
        autoCopyOnOpen: true,
      });
    }
  }

  function detectMarketplace() {
    const host = window.location.hostname.toLowerCase();
    if (host.includes('mercadolivre') || host.includes('mercadolibre')) return 'mercadolivre';
    if (host.includes('shopee')) return 'shopee';
    if (host.includes('amazon')) return 'amazon';
    return 'other';
  }

  function buildAffiliateLink(rawUrl, marketplace, tags) {
    try {
      // If already a recognized short affiliate link (sec, amzn.to, s.shopee), preserve it
      if (rawUrl.includes('/sec/') || rawUrl.includes('amzn.to') || rawUrl.includes('s.shopee.com')) {
        return rawUrl;
      }

      const urlObj = new URL(rawUrl);

      if (marketplace === 'mercadolivre') {
        urlObj.searchParams.set('matt_tool', 'affiliate_zap');
        urlObj.searchParams.set('tracking_id', tags.meliTag || 'afiliado_zap_vip');
        return urlObj.toString();
      }

      if (marketplace === 'shopee') {
        urlObj.searchParams.set('aff_id', tags.shopeeTag || 'shopee_vip_123');
        urlObj.searchParams.set('sub_id', 'whatsapp_bot');
        return urlObj.toString();
      }

      if (marketplace === 'amazon') {
        urlObj.searchParams.set('tag', tags.amazonTag || 'achadoszap-20');
        return urlObj.toString();
      }

      return rawUrl;
    } catch {
      return rawUrl;
    }
  }

  function extractProductData(tags) {
    const marketplace = detectMarketplace();
    const rawUrl = window.location.href;
    const affiliateUrl = buildAffiliateLink(rawUrl, marketplace, tags || {});

    let title = '';
    let imageUrl = '';
    let originalPrice = 0;
    let promotionalPrice = 0;
    let externalId = '';
    let installments = '';
    let freeShipping = false;
    let couponCode = '';

    if (marketplace === 'mercadolivre') {
      // Clean title
      const titleEl = document.querySelector('h1.ui-pdp-title') || document.querySelector('h1');
      title = titleEl ? titleEl.innerText.trim() : document.title.replace(' | Mercado Livre', '').replace(' | MercadoLivre.com.br', '').trim();

      // First High-Res Image (prefer -O.webp)
      const ogImg = document.querySelector('meta[property="og:image"]');
      const figureImg =
        document.querySelector('.ui-pdp-gallery__figure img') ||
        document.querySelector('img.ui-pdp-image') ||
        document.querySelector('figure img') ||
        document.querySelector('.ui-pdp-gallery img');
      imageUrl = (ogImg && ogImg.content) || (figureImg && figureImg.src) || '';

      // Upgrade thumbnail to high resolution full size
      if (imageUrl && imageUrl.includes('-I.webp')) {
        imageUrl = imageUrl.replace('-I.webp', '-O.webp');
      } else if (imageUrl && imageUrl.includes('-V.webp')) {
        imageUrl = imageUrl.replace('-V.webp', '-O.webp');
      }

      // External MLB ID
      const mlbMatch =
        window.location.pathname.match(/(MLB-?\d+)/i) ||
        window.location.pathname.match(/\/p\/(MLB\d+)/i) ||
        window.location.href.match(/(MLB\d+)/i);
      externalId = mlbMatch ? mlbMatch[1].replace('-', '').toUpperCase() : '';

      // Prices
      const promoFraction = document.querySelector('.ui-pdp-price__second-line .andes-money-amount__fraction');
      const promoCents = document.querySelector('.ui-pdp-price__second-line .andes-money-amount__cents');
      if (promoFraction) {
        const val = promoFraction.innerText.replace(/\./g, '') + '.' + (promoCents ? promoCents.innerText : '00');
        promotionalPrice = parseFloat(val) || 0;
      }

      const origFraction = document.querySelector('.ui-pdp-price__original-value .andes-money-amount__fraction');
      if (origFraction) {
        originalPrice = parseFloat(origFraction.innerText.replace(/\./g, '')) || 0;
      } else {
        originalPrice = promotionalPrice > 0 ? Number((promotionalPrice * 1.3).toFixed(2)) : 0;
      }

      // Installments
      const instEl = document.querySelector('.ui-pdp-media--installments') || document.querySelector('.ui-pdp-installments');
      installments = instEl ? instEl.innerText.replace(/\s+/g, ' ').trim() : 'Em até 10x sem juros';

      // Free shipping
      const shippingEl = document.querySelector('.ui-pdp-media--shipping') || document.querySelector('.ui-pdp-shipping');
      freeShipping = !!(shippingEl && shippingEl.innerText.toLowerCase().includes('grátis'));

      // Coupon
      const couponEl = document.querySelector('.ui-pdp-promotions__coupon, .ui-pdp-coupons, .ui-pdp-promotions__badge');
      if (couponEl) {
        const match = couponEl.innerText.match(/([A-Z0-9]{4,15})/);
        if (match) couponCode = match[1];
      }
    } else if (marketplace === 'shopee') {
      const titleEl = document.querySelector('h1') || document.querySelector('._44qnta') || document.querySelector('div[data-sqe="item_name"]');
      title = titleEl ? titleEl.innerText.trim() : document.title;

      const ogImg = document.querySelector('meta[property="og:image"]');
      const shopeeImg = document.querySelector('._39_Twn img') || document.querySelector('picture img');
      imageUrl = (ogImg && ogImg.content) || (shopeeImg && shopeeImg.src) || '';

      const priceEl = document.querySelector('.pqTWkA') || document.querySelector('.G27FPf');
      if (priceEl) {
        const num = priceEl.innerText.replace(/[^\d,]/g, '').replace(',', '.');
        promotionalPrice = parseFloat(num) || 0;
        originalPrice = Number((promotionalPrice * 1.25).toFixed(2));
      }

      const idMatch = window.location.pathname.match(/-i\.(\d+\.\d+)/) || window.location.href.match(/item\/(\d+)/);
      externalId = idMatch ? `shopee_${idMatch[1]}` : '';
      installments = 'Até 6x sem juros';
      freeShipping = true;
    } else if (marketplace === 'amazon') {
      const titleEl = document.querySelector('#productTitle') || document.querySelector('h1#title');
      title = titleEl ? titleEl.innerText.trim() : document.title;

      const landingImg = document.querySelector('#landingImage') || document.querySelector('#imgBlkFront');
      const ogImg = document.querySelector('meta[property="og:image"]');
      imageUrl = (landingImg && landingImg.src) || (ogImg && ogImg.content) || '';

      const asinMatch =
        window.location.pathname.match(/\/dp\/([A-Z0-9]{10})/i) ||
        window.location.pathname.match(/\/gp\/product\/([A-Z0-9]{10})/i) ||
        window.location.href.match(/([A-Z0-9]{10})/);
      externalId = asinMatch ? asinMatch[1] : '';

      const priceEl = document.querySelector('.a-price .a-offscreen') || document.querySelector('#priceblock_dealprice');
      if (priceEl) {
        const num = priceEl.innerText.replace(/[^\d,]/g, '').replace(',', '.');
        promotionalPrice = parseFloat(num) || 0;
        originalPrice = Number((promotionalPrice * 1.2).toFixed(2));
      }
      installments = 'Até 10x sem juros';
      freeShipping = true;
    }

    const discountPercentage =
      originalPrice > promotionalPrice && originalPrice > 0
        ? Math.round(((originalPrice - promotionalPrice) / originalPrice) * 100)
        : 0;

    return {
      title,
      imageUrl,
      originalUrl: rawUrl,
      affiliateUrl,
      originalPrice,
      promotionalPrice: promotionalPrice || 99.9,
      discountPercentage,
      marketplace,
      externalId,
      installments,
      freeShipping,
      couponCode,
    };
  }

  // Formata a mensagem no modelo EXATO de ACHADINHOS VIRAL DO WHATSAPP
  function formatAchadinhoWhatsApp(prod) {
    const promoStr = prod.promotionalPrice.toFixed(2).replace('.', ',');
    const origStr = prod.originalPrice.toFixed(2).replace('.', ',');

    const origLine =
      prod.originalPrice > prod.promotionalPrice
        ? `❌ De: ~R$ ${origStr}~\n`
        : '';

    const discountBadge = prod.discountPercentage > 0 ? ` (${prod.discountPercentage}% OFF!)` : '';
    const installmentsLine = prod.installments ? `💳 ${prod.installments}\n` : '';
    const shippingLine = prod.freeShipping ? '🚚 *Frete Grátis Liberado!*\n' : '';
    const couponLine = prod.couponCode ? `🎟️ Cupom de Desconto: *${prod.couponCode}*\n` : '';

    return (
      `🔥 *ACHADINHO DO DIA!* 🔥\n\n` +
      `📦 *${prod.title}*\n\n` +
      origLine +
      `🔥 *Por apenas: R$ ${promoStr}*${discountBadge}\n` +
      installmentsLine +
      shippingLine +
      couponLine +
      `\n🛒 *Compre aqui com desconto:* \n👉 ${prod.affiliateUrl}\n\n` +
      `⚠️ _Atenção: Os preços e estoques podem variar a qualquer momento._`
    );
  }

  // Notificação no topo da tela estilo Toast
  function showTopNotification(text, isSuccess = true) {
    const existing = document.getElementById('zapafiliados-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'zapafiliados-toast';
    toast.style.cssText = `
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 99999999;
      background: ${isSuccess ? '#064e3b' : '#1e293b'};
      color: #fff;
      border: 2px solid ${isSuccess ? '#10b981' : '#334155'};
      padding: 12px 20px;
      border-radius: 9999px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      font-weight: 800;
      box-shadow: 0 10px 30px rgba(0,0,0,0.6), 0 0 20px rgba(16, 185, 129, 0.3);
      display: flex;
      align-items: center;
      gap: 10px;
      animation: zapSlideDown 0.3s ease;
      cursor: pointer;
    `;

    toast.innerHTML = `
      <span style="font-size: 16px;">🔥</span>
      <span>${text}</span>
      <span style="font-size: 11px; opacity: 0.7; margin-left: 6px;">✕</span>
    `;

    toast.onclick = () => toast.remove();
    document.body.appendChild(toast);

    setTimeout(() => {
      if (toast.parentNode) toast.remove();
    }, 4500);
  }

  // Injeta o widget flutuante e auto-copia se configurado
  function injectAchadinhoWidget() {
    const path = window.location.pathname;
    const isProductPage =
      path.includes('/p/MLB') ||
      path.includes('MLB-') ||
      path.includes('MLB') ||
      path.includes('/dp/') ||
      path.includes('/gp/product/') ||
      path.includes('-i.') ||
      path.includes('/produto/');

    if (!isProductPage) return;

    getSettings((settings) => {
      const prod = extractProductData(settings);
      if (!prod.title) return;

      const achadinhoText = formatAchadinhoWhatsApp(prod);

      // Auto-copiar ao entrar na página se a opção estiver ativa
      if (settings.autoCopyOnOpen) {
        navigator.clipboard.writeText(achadinhoText).then(() => {
          showTopNotification('🔥 Achadinho Copiado! Cole no WhatsApp (Link + Foto + Preço)');
        }).catch(() => {
          // fallback if blocked by focus
        });
      }

      // Evita criar múltiplos widgets
      if (document.getElementById('zapafiliados-achadinho-widget')) return;

      const container = document.createElement('div');
      container.id = 'zapafiliados-achadinho-widget';
      container.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 9999999;
        background: #090d16;
        border: 2px solid #10b981;
        border-radius: 20px;
        box-shadow: 0 25px 50px rgba(0,0,0,0.85), 0 0 25px rgba(16, 185, 129, 0.35);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #fff;
        padding: 16px;
        width: 340px;
        max-width: 90vw;
        backdrop-filter: blur(14px);
        transition: all 0.3s ease;
      `;

      container.innerHTML = `
        <!-- Top bar -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #1e293b; padding-bottom: 8px;">
          <div style="display: flex; align-items: center; gap: 7px;">
            <div style="width: 24px; height: 24px; border-radius: 7px; background: linear-gradient(135deg, #10b981, #059669); color: #000; font-weight: 900; font-size: 13px; display: flex; align-items: center; justify-content: center;">🔥</div>
            <span style="font-weight: 900; font-size: 13px; color: #fff; letter-spacing: -0.3px;">Achadinho WhatsApp</span>
          </div>
          <button id="zap-close-btn" style="background: transparent; border: none; color: #64748b; font-size: 16px; cursor: pointer; padding: 2px 6px;">✕</button>
        </div>

        <!-- Product Thumbnail & Title -->
        <div style="display: flex; gap: 10px; margin-bottom: 12px; background: #020617; padding: 10px; border-radius: 12px; border: 1px solid #1e293b;">
          ${
            prod.imageUrl
              ? `<img id="zap-prod-img" src="${prod.imageUrl}" style="width: 58px; height: 58px; object-fit: cover; border-radius: 8px; border: 1px solid #334155; shrink-0;" />`
              : `<div style="width: 58px; height: 58px; background: #1e293b; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 22px;">📦</div>`
          }
          <div style="min-width: 0; flex: 1;">
            <div style="font-size: 11px; font-weight: 700; color: #f8fafc; line-height: 1.3; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
              ${prod.title || 'Produto'}
            </div>
            <div style="margin-top: 4px; display: flex; align-items: baseline; gap: 6px;">
              <span style="font-size: 15px; font-weight: 900; color: #10b981;">R$ ${prod.promotionalPrice.toFixed(2).replace('.', ',')}</span>
              ${prod.originalPrice > prod.promotionalPrice ? `<span style="font-size: 11px; color: #64748b; text-decoration: line-through;">R$ ${prod.originalPrice.toFixed(2).replace('.', ',')}</span>` : ''}
              ${prod.discountPercentage > 0 ? `<span style="font-size: 10px; font-weight: 900; background: #f43f5e; color: #fff; padding: 1px 4px; border-radius: 4px;">${prod.discountPercentage}% OFF</span>` : ''}
            </div>
          </div>
        </div>

        <!-- Anti-Duplication Status -->
        <div id="zap-dup-status" style="font-size: 11px; margin-bottom: 12px; padding: 6px 10px; border-radius: 8px; background: #0f172a; border: 1px solid #1e293b;">
          Verificando duplicação no robô...
        </div>

        <!-- Action 1: Copy Achadinho Text (WhatsApp) -->
        <button id="zap-copy-achadinho-btn" style="
          width: 100%;
          background: linear-gradient(135deg, #10b981, #059669);
          color: #020617;
          font-weight: 900;
          font-size: 12px;
          padding: 12px;
          border-radius: 12px;
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          margin-bottom: 8px;
          box-shadow: 0 4px 14px rgba(16, 185, 129, 0.4);
          transition: transform 0.15s;
        ">
          <span>📋 Copiar Texto Achadinho (WhatsApp)</span>
        </button>

        <!-- Actions: Send to Bot & Download Photo -->
        <div style="display: flex; gap: 8px; margin-bottom: 8px;">
          <button id="zap-send-bot-btn" style="
            flex: 1;
            background: #1e293b;
            color: #f1f5f9;
            font-weight: 700;
            font-size: 11px;
            padding: 9px 10px;
            border-radius: 10px;
            border: 1px solid #334155;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
          ">
            <span>⚡ Programador do Dia</span>
          </button>

          ${
            prod.imageUrl
              ? `<a href="${prod.imageUrl}" target="_blank" download="achadinho-foto.webp" style="
                  background: #1e293b;
                  color: #94a3b8;
                  font-weight: 600;
                  font-size: 11px;
                  padding: 9px 12px;
                  border-radius: 10px;
                  border: 1px solid #334155;
                  text-decoration: none;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 4px;
                ">
                  <span>🖼️ 1ª Foto</span>
                </a>`
              : ''
          }
        </div>

        <!-- Auto-copy info footer -->
        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 10px; color: #94a3b8; padding-top: 6px; border-top: 1px solid #1e293b;">
          <span>⚡ Auto-copiar ao clicar: <strong>${settings.autoCopyOnOpen ? 'Ativado' : 'Desativado'}</strong></span>
          <span style="color: #10b981; font-weight: 700;">Tag: ${settings.meliTag}</span>
        </div>
      `;

      document.body.appendChild(container);

      // Close handler
      const closeBtn = document.getElementById('zap-close-btn');
      if (closeBtn) closeBtn.onclick = () => container.remove();

      // Check Duplication with ZapAfiliados Backend
      const dupStatus = document.getElementById('zap-dup-status');
      const checkUrl = `${settings.serverUrl}/api/extension/check?url=${encodeURIComponent(prod.originalUrl)}&externalId=${encodeURIComponent(prod.externalId || '')}&title=${encodeURIComponent(prod.title || '')}`;

      fetch(checkUrl)
        .then((r) => r.json())
        .then((res) => {
          if (res.exists) {
            dupStatus.style.background = '#451a03';
            dupStatus.style.borderColor = '#b45309';
            dupStatus.innerHTML = `
              <div style="color: #fbbf24; font-weight: 700;">⚠️ Produto Já Divulgado!</div>
              <div style="color: #cbd5e1; font-size: 10px;">Anti-repetição ativo. Evite repetir nos grupos.</div>
            `;
          } else {
            dupStatus.style.background = '#064e3b';
            dupStatus.style.borderColor = '#059669';
            dupStatus.innerHTML = `
              <div style="color: #34d399; font-weight: 700;">✨ Produto Inédito (Novo)!</div>
              <div style="color: #cbd5e1; font-size: 10px;">Pronto para copiar ou programar o disparo.</div>
            `;
          }
        })
        .catch(() => {
          dupStatus.innerHTML = `<span style="color: #94a3b8;">Link de afiliado gerado com sua tag!</span>`;
        });

      // Copy Achadinho Text to Clipboard
      const copyBtn = document.getElementById('zap-copy-achadinho-btn');
      if (copyBtn) {
        copyBtn.onclick = () => {
          navigator.clipboard.writeText(achadinhoText).then(() => {
            copyBtn.style.background = '#059669';
            copyBtn.innerHTML = '<span>✅ Copiado! Cole no WhatsApp</span>';
            showTopNotification('✅ Texto copiado no estilo Achadinhos WhatsApp!');
            setTimeout(() => {
              copyBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
              copyBtn.innerHTML = '<span>📋 Copiar Texto Achadinho (WhatsApp)</span>';
            }, 3000);
          });
        };
      }

      // Send to ZapAfiliados Bot for Daily Dispatch
      const sendBotBtn = document.getElementById('zap-send-bot-btn');
      if (sendBotBtn) {
        sendBotBtn.onclick = () => {
          sendBotBtn.disabled = true;
          sendBotBtn.innerHTML = '<span>Enviando...</span>';

          fetch(`${settings.serverUrl}/api/extension/import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              ...prod,
              addToDailySchedule: true,
            }),
          })
            .then((r) => r.json())
            .then((res) => {
              if (res.success) {
                sendBotBtn.style.background = '#10b981';
                sendBotBtn.style.color = '#000';
                sendBotBtn.innerHTML = '<span>✅ Agendado Hoje!</span>';
                showTopNotification('⚡ Produto agendado no Programador do Dia sem repetir!');
              } else if (res.duplicate) {
                sendBotBtn.style.background = '#f59e0b';
                sendBotBtn.style.color = '#000';
                sendBotBtn.innerHTML = '<span>⚠️ Já no Robô</span>';
              } else {
                sendBotBtn.disabled = false;
                sendBotBtn.innerHTML = '<span>Tentar de novo</span>';
              }
            })
            .catch(() => {
              sendBotBtn.disabled = false;
              sendBotBtn.innerHTML = '<span>Erro conexão</span>';
            });
        };
      }
    });
  }

  // Also support clicking affiliate links or product cards on Mercado Livre, Shopee or Amazon
  function attachClickListener() {
    document.addEventListener('click', (e) => {
      const target = e.target;
      const link = target.closest('a');
      if (!link || !link.href) return;

      const href = link.href;
      const isAffiliateOrProductLink =
        href.includes('/sec/') ||
        href.includes('amzn.to') ||
        href.includes('s.shopee.com') ||
        href.includes('/p/MLB') ||
        href.includes('MLB-') ||
        href.includes('/dp/') ||
        href.includes('/gp/product/');

      if (isAffiliateOrProductLink) {
        // Quick visual indicator that the extension is ready to capture
        getSettings((settings) => {
          if (settings.autoCopyOnOpen) {
            // When navigating, the page will auto-copy on load
          }
        });
      }
    }, { passive: true });
  }

  // Detect and inject
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      injectAchadinhoWidget();
      attachClickListener();
    });
  } else {
    setTimeout(() => {
      injectAchadinhoWidget();
      attachClickListener();
    }, 700);
  }

  // Also listen for runtime message from popup
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
      if (req.action === 'extract_product') {
        getSettings((settings) => {
          const prod = extractProductData(settings);
          const achadinhoText = formatAchadinhoWhatsApp(prod);
          sendResponse({ product: prod, achadinhoText });
        });
        return true;
      }
    });
  }
})();
